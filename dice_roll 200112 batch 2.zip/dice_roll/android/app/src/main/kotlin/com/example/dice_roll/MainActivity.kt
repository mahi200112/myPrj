package com.example.dice_roll

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
